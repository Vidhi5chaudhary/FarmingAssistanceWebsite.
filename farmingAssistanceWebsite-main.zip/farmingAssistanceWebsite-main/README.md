# farmingAssistanceWebsite
A simple, responsive Farming Assistance Website built using HTML, CSS, and JavaScript. It provides static crop information, government schemes, and best practices for farmers. Features include a toggleable chatbot for guidance, clean UI, glowing hover effects, and organized modular structure for easy updates.
